Please credit all creators if you include this in a pack in any form, follow all liscenses and permissions of both compliance/faithful and Fresh Animations
Ensure you are following the most up to date liscenses as below might be outdated
-----------------------------------------------------------------------------------------------------------------------------------------------------------

Faithful Resource Pack License

BY USING FAITHFUL YOU AGREE TO THESE TERMS AND CONDITIONS. IF YOU DISTRIBUTE FAITHFUL IN ANY FORM, THIS LICENSE MUST BE INCLUDED INSIDE OF THE ZIP FILE.
Definitions

The pack refers to any copyrightable work licensed under this license.
The Faithful Team staff refers to the persons in possession of the Discord accounts with the online nicknames Sei#0721, Juknum#0001, HARAG0N#1897, Pomi108#1378, RobertR11#7841 and Ninventoo#5994.
A pack can be considered to be an add-on if it can only work in combination with the original pack in a way that makes sense.
A pack can be considered to be a streamer pack or a youtuber pack if it was made by or on behalf of a streamer or a youtuber.
Distribution of The Pack

If you wish to distribute the pack (whether that is a modified copy or an identical copy), you have to comply with the following terms and conditions:

    You are required to get permission from the Faithful Team staff.
    You are required to link back to https://www.faithfulpack.net in an appropriate place.
    You may not make money off of the pack in any form.
    You are required to include this license in all copies.

Exceptions

You are not required to get permission from the Faithful Team staff if your pack can be considered to be an add-on.
Usage of The Pack

The pack may be used...

    For placeholder textures.
    For replacing a small amount of textures you are unable to make yourself.
    For streamer or youtuber packs.
    During a stream or a video.
    As a base for mod or map textures.

Final Note

The Faithful Team staff has the final say over any distribution and usage of the pack. We have the right to deny anyone the distribution or re-use of the pack. If you do not follow the terms and conditions of this license, legal action may be taken. 

-----------------------------------------------------------------------------------------------------------------------------------------------------------
 Fresh Animations is owned and created by FreshLX
 
 Planet Minecraft: https://www.planetminecraft.com/member/freshlx/
 
 CurseForge: https://www.curseforge.com/members/freshlx_official/projects
 
 Twitter: https://twitter.com/Fresh_LX
 
 Youtube: https://www.youtube.com/channel/UCCs_JwXYjjgeRIujTlbswIw
______________________________

 Creative Commons License:
______________________________

 This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.
 
 More info here > https://creativecommons.org/licenses/by-nc-sa/4.0/

______________________________

 Permissions:
______________________________

  Feel free to include this resource pack in your mod pack or server.
  
  If you wish to use this pack in any form of content, please credit with a link to the original CurseForge or PMC page where you can.





